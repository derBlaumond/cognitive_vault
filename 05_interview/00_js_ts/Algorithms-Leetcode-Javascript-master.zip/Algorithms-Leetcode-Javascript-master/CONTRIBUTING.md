# Contributing

## Pull Request Process

1. Update the README.md with the new problem (if there is any).
2. Add the common method to be executed when we run all of them by exposing the main function.
3. Add tests if possible.
4. Open a pull request.
