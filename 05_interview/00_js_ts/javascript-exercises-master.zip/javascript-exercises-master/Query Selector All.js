0. document.getElementsByTagName("*");
1. document.querySelectorAll("p.big");
2. document.getElementById("main").getElementsByTagName("p")[0];
   document.querySelectorAll("#main p:first-child");
3. document.querySelectorAll("tr:nth-child(odd)");
4. document.querySelectorAll("input[type=textarea]");
